<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
</head>
<body>
   <table border=2>
      <h1>User</h1>
      <tr>
         <th>userId</th>
         <th>name</th>
         <th>city</th>
      </tr>
      <?php
      include('connection.php');
      $query = "select *from user"; 
      $result = mysqli_query($conn_user , $query);
      while($rows = mysqli_fetch_assoc($result)){
         $userId = $rows['userId'];
         $name = $rows['name'];
         $city = $rows['city'];
         echo "<tr>
                <td>$userId</td>
                <td>$name</td>
                <td>$city</td>
               </tr>";
      }
      ?>
   </table>
   <div style="position:absolute;left:20%;top:0%;">
   <table border=2 >
      <h1>UserDetail </h1>
      <tr>
         <th>id</th>
         <th>foreignId</th>
         <th>name</th>
         <th>city</th>
      </tr>
      <?php
      include('connection.php');
      $query = "select *from userDetail"; 
      $result = mysqli_query($conn_user , $query);
      while($rows = mysqli_fetch_assoc($result)){
         $id = $rows['id'];
         $foreignId = $rows['foreignId'];
         $address = $rows['address'];
         $phoneNumber = $rows['phoneNumber'];
         echo "<tr>
                <td>$id</td>
                <td>$foreignId</td>
                <td>$name</td>
                <td>$city</td>
               </tr>";
      }
      ?>
   </table>
   </div>
</body>
</html>