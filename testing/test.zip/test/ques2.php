<?php
 $a  = <<<end
       hello
       end;
echo $a;

?>