<?php 
  session_start();
  $_SESSION['name']='Harvinder Singh';
  $_SESSION['age']='21';
  if($_SESSION['name']){
    echo "session value  setted";
  }
?>