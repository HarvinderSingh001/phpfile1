<?php
// constants are declared or accessed without dollars sign
 const collegeName= "jmit";
  $collegeName="mln";
echo collegeName; 

?>
